package com.mi22a.utsalim

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.mi22a.utsalim.databinding.ItemCourseBinding

class CourseAdapter(val data : ArrayList <Course>):
        RecyclerView.Adapter <CourseAdapter.CourseViewHolder>(){

    class CourseViewHolder(val view :ItemCourseBinding ) : RecyclerView.ViewHolder (view.root)

    override fun onCreatViewHolder(parent:ViewGroup, viewType: Int): CourseViewHolder {
        val view =ItemCourseBinding.inflate(LayoutInflater.from(parent.context),parent, false)
        return CourseViewHolder(view)
    }

    override fun getItemCount()= data.size

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val course = data [position]
        holder.view.tvTitle.text =course.title
        holder.view.tvPath.text =course.path
        holder.view.ivCourse.load(course.image)
    }
}